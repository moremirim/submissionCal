class Calculator {
    
    func add(x: Double, y: Double) -> Double {
        return 0
    }
    func subtract(x: Double, y: Double) -> Double {
        return 0
    }
    func multiply(x: Double, y: Double) -> Double {
        return 0
    }
    func divide(x: Double, y: Double) -> Double {
        return 0
    }
}




class AddOperation: Calculator {
    override func add(x: Double, y: Double) -> Double {
        return x + y
    }
}

class SubtractOperation: Calculator {
    override func subtract(x: Double, y: Double) -> Double {
        return x - y
    }
}

class MultiplyOperation: Calculator {
    override func multiply(x: Double, y: Double) -> Double {
        return x * y
    }
}

class DivideOperation: Calculator {
    override func divide(x: Double, y: Double) -> Double {
        return x / y
    }
}

var addResult = AddOperation().add(x: 2, y: 5)
var subtractResult = SubtractOperation().subtract(x: 10, y: 2)
var multiplyResult = MultiplyOperation().multiply(x: 5.0, y: 2.3)
var divideResult = DivideOperation().divide(x: 9.6, y: 2.0)
print("addResult : \(addResult)")
print("subtractResult : \(subtractResult)")
print("multiplyResult : \(multiplyResult)")
print("divideResult : \(divideResult)")
