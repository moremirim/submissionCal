//lv1,2 와 lv3
//두 개의 페이지로 구성

class Calculator {
    
    func add(x: Double, y: Double) -> Double {
        return x + y
    }
    func subtract(x: Double, y: Double) -> Double {
        return x - y
    }
    func multiply(x: Double, y: Double) -> Double {
        return x * y
    }
    func divide(x: Double, y: Double) -> Double {
        return (x / y)
    }
    func modular(x: Double, y: Double) -> Int {
        return Int(x) % Int(y)
    }
}

let calculator = Calculator()

var addResult = calculator.add(x: 5, y: 10)
print(addResult)
var subtractResult = calculator.subtract(x: 2.5, y: 1.3)
print(subtractResult)
var multiplyResult = calculator.multiply(x: 3.4, y: 2.0)
print(multiplyResult)
var divideResult = calculator.divide(x: 6, y: 3)
print(divideResult)
var modularResult = calculator.modular(x: 5, y: 3)
print(modularResult)
